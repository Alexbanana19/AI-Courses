#!/usr/bin/env python
import matplotlib.pyplot as plt
import pickle

with open("results9.pkl", "rb") as dataFile:
    data9 = pickle.loads(dataFile.read())

with open("results8.pkl", "rb") as dataFile:
    data8 = pickle.loads(dataFile.read())

with open("results8n2.pkl", "rb") as dataFile:
    data8n2 = pickle.loads(dataFile.read())

with open("results8n3.pkl", "rb") as dataFile:
    data8n3 = pickle.loads(dataFile.read())

with open("results8n4.pkl", "rb") as dataFile:
    data8n4 = pickle.loads(dataFile.read())

with open("results8n8.pkl", "rb") as dataFile:
    data8n8 = pickle.loads(dataFile.read())

with open("results4.pkl", "rb") as dataFile:
    data4 = pickle.loads(dataFile.read())

with open("results4n2.pkl", "rb") as dataFile:
    data4n2 = pickle.loads(dataFile.read())

with open("results4n3.pkl", "rb") as dataFile:
    data4n3 = pickle.loads(dataFile.read())

with open("results4n4.pkl", "rb") as dataFile:
    data4n4 = pickle.loads(dataFile.read())

#print data
#plt.plot(data4.tolist(), label = '1 step 4-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
#plt.plot(data4n2.tolist(), label = '2 step 4-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
#plt.plot(data4n3.tolist(), label = '3 step 4-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
#plt.plot(data4n4.tolist(), label = '4 step 4-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
plt.plot(data8.tolist(), label = '1 step king-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
plt.plot(data8n2.tolist(), label = '2 step king-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
plt.plot(data8n3.tolist(), label = '3 step king-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
plt.plot(data8n4.tolist(), label = '4 step king-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
plt.plot(data8n8.tolist(), label = '8 step king-moves, gamma = 0.9, alpha = 0.5, epsilon = 0.1')
#plt.plot(data9.tolist(), label = '1 step 9-moves(king-moves + rest), gamma = 0.9, alpha = 0.5, epsilon = 0.1')
plt.xlabel('Steps')
plt.ylabel('Episodes')
plt.title('N-Step SARSA averge over 50 runs')
plt.legend()
plt.show()
